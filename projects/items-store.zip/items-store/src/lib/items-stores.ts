import { Inject, Injectable } from '@angular/core';
import { ItemsStoreConfig, ItemsStoreConfigToken } from './items-store.config';
import { ItemsStore } from './items-store';

@Injectable()
export class ItemsStores {
  constructor(@Inject(ItemsStoreConfigToken) private _config: ItemsStoreConfig) {

  }

  get(type: string): ItemsStore<any> {
    const repository = this._config[type];

    if (!repository)
      throw new Error(`Invalid repository for ${type}`);

    return new ItemsStore(repository) as ItemsStore;
  }
}
